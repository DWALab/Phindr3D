
% Add Paths to Library

addpath(genpath(pwd));

% Open Main Window
set(0, 'DefaultFigureRenderer', 'painters');
PhinDR3D_Main;