Instructions to Run PhindR3D

Steps

1) Extract zip files to specific directory
2) Open Matlab
3) Navigate to directory where the zip files were extracted in Matlab
4) Go to Matlab command prompt
5) Type "Phindr3D" in the command prompt and hit Enter
6) See Phindr3D_UserManual.PDF for details


Alternatively:
Run the executable to install the program. You will be asked to install the Matlab runtime if it is unavailable on the computer.
