Copy organoid images to specific folder (i.e. \\...\OncogeneSegmentation\RawData\)

Extract metadata using Phindr3D' metadata extractor

Open Matlab and navigate to the above destination

1) Type organoidSegmentation in command prompt and hit run
2) Select Metadata File
3) Select Channels
4) Select Segmentation Channels [Nucleus Channel]

See Phindr3D_UserManual.PDF for details.

****** TO CHANGE PARAMETERS ************

Open "organoidSegmentation.m" in Matlab editor

You can change values of different parameters listed under "Segmentation Parameters" section.

Save the file and run it as given in 1 above


****************************************
Alternatively:
Run the executable to install the program. You will be asked to install the Matlab runtime if it is unavailable on the computer.
Afterwards, follow instructions from step 2) on.
